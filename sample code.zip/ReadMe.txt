This is a asp.net website which allows user to register as admin to create, 
delete, edit posts, or register as general user to create, edit his own posts.
The .net core version was 3.0/3.1, which is kinda out of date, but the codes
are still worth looking at. Thanks for your patience!

The databased was created with Azure Portal, which is cloud based. Also, 
this website has been publish at address: https://ttpost.azurewebsites.net/.
You are welcome to visit and leave your post!
